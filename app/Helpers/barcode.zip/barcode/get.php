<?php

require 'vendor/autoload.php';

function make_barcode($melli)
{
    $generator = new Picqer\Barcode\BarcodeGeneratorJPG();
    file_put_contents(ROOT.'barcodes/'.$melli.'.jpg', $generator->getBarcode($melli, $generator::TYPE_CODABAR));
}
